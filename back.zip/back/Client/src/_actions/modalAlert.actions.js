import { modalAlertConstants } from '../_constants';

export const modalAlertActions = {
    success,
    error,
    clear
};

function success(message) {
    return { type: modalAlertConstants.SUCCESS, message };
}

function error(message) {
    return { type: modalAlertConstants.ERROR, message };
}

function clear() {
    return { type: modalAlertConstants.CLEAR };
}