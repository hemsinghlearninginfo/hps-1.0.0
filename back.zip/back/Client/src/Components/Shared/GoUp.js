import React from 'react';
import { Icon } from '../../_controls/Icon';
export const GoUp = () => (
    <div className="go-up">
        <Icon type='Up' />
    </div>
);
