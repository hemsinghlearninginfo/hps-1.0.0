import React from 'react';
const Wrapper = (props) => (<>{props.children}</>);
export default Wrapper;