import React from 'react';
import {PageTemplate} from '../../_controls';
export const TermsAndConditions = () => (
    <PageTemplate heading="Terms and Conditions">
    User Agrement
    </PageTemplate>
);
