export const modalAlertConstants = {
    SUCCESS: 'MODAL_ALERT_SUCCESS',
    ERROR: 'MODAL_ALERT_ERROR',
    CLEAR: 'MODAL_ALERT_CLEAR'
};
