export const Role = {
    SuperAdmin: 'SuperAdmin',
    Admin: 'Admin',
    Master: 'Master',
    User: 'User'    
}