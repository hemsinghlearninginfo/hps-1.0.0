import * as postsActions from './actionCreators';
import * as postsSelectors from './selectors';

export {
  postsActions,
  postsSelectors,
};
