import React from 'react';

export class Dashboard extends React.Component {
  render() {
    return (
      <div className="jumbotron">
        <h1>react-redux-crud</h1>
        <p>
          React + Redux CRUD demo
        </p>
      </div>
    );
  }
}
